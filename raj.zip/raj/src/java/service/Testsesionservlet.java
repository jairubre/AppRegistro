/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
 
/**
 * ⚠️ CLASE TEMPORAL SOLO PARA PROBAR EN LOCAL. BORRAR ANTES DE ENTREGAR. ⚠️
 *
 * Sirve para probar el endpoint de cambio de contraseña mientras el login
 * real no está hecho. Es peligrosa a propósito (permite "loguearse" como
 * cualquier email sin contraseña), por eso NO debe quedar en el proyecto.
 *
 * Uso (desde el navegador):
 *   1) Generar un hash:
 *      http://localhost:8080/raj/test-sesion?accion=hash&password=Vieja123
 *   2) Simular un login (guarda el email en la sesión):
 *      http://localhost:8080/raj/test-sesion?accion=login&email=tu@email.com
 */
// @WebServlet: registra el servlet en la URL /test-sesion.
// Al ser un servlet, NO hace falta añadirlo a ApplicationConfig.
@WebServlet("/test-sesion")
public class Testsesionservlet extends HttpServlet {
 
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
 
        resp.setContentType("text/plain;charset=UTF-8");
        String accion = req.getParameter("accion");
 
        if ("hash".equals(accion)) {
            // Devuelve el hash de la contraseña recibida, para pegarlo
            // en la base de datos con un UPDATE.
            String password = req.getParameter("password");
            if (password == null || password.isBlank()) {
                resp.getWriter().println("Falta el parametro password");
                return;
            }
            resp.getWriter().println(Password.hash(password));
 
        } else if ("login".equals(accion)) {
            // Simula un login: guarda el email en la sesion con el MISMO
            // nombre de atributo que lee ChangePasswordResource ("email").
            String email = req.getParameter("email");
            if (email == null || email.isBlank()) {
                resp.getWriter().println("Falta el parametro email");
                return;
            }
            req.getSession(true).setAttribute("email", email);
            resp.getWriter().println("Sesion creada para: " + email);
 
        } else {
            resp.getWriter().println("Usa ?accion=hash&password=... o ?accion=login&email=...");
        }
    }
}
